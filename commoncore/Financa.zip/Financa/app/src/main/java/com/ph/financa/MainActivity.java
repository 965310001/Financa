package com.ph.financa;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.app.Fragment;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.ViewAnimationUtils;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import com.next.easynavigation.constant.Anim;
import com.next.easynavigation.utils.NavigationUtil;
import com.next.easynavigation.view.EasyNavigationBar;
import com.ph.financa.fragments.CustomerFragment;
import com.ph.financa.fragments.HomeFragment;
import com.ph.financa.fragments.MeFragment;
import com.ph.financa.fragments.SeeFragment;

import java.util.ArrayList;
import java.util.List;

import tech.com.commoncore.base.BaseActivity;
import tech.com.commoncore.base.BaseFragment;

public class MainActivity extends AppCompatActivity {

    private EasyNavigationBar navigationBar;

    private String[] tabText = {"首页", "发现", "", "消息", "我的"};
    //未选中icon
    private int[] normalIcon = {R.mipmap.index, R.mipmap.find, R.mipmap.add_image, R.mipmap.message, R.mipmap.me};
    //选中时icon
    private int[] selectIcon = {R.mipmap.index1, R.mipmap.find1, R.mipmap.add_image, R.mipmap.message1, R.mipmap.me1};

    private List<BaseFragment> fragments = new ArrayList<>();

    //仿微博图片和文字集合
    private int[] menuIconItems = {R.mipmap.pic1, R.mipmap.pic2, R.mipmap.pic3, R.mipmap.pic4};
    private String[] menuTextItems = {"文字", "拍摄", "相册", "直播"};

    private LinearLayout menuLayout;
    private View cancelImageView;
    private Handler mHandler = new Handler();

  /*  @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }*/

    //仿微博弹出菜单
//    private View createWeiboView() {
//        ViewGroup view = (ViewGroup) View.inflate(WeiboActivity.this, R.layout.layout_add_view, null);
//        menuLayout = view.findViewById(R.id.icon_group);
//        cancelImageView = view.findViewById(R.id.cancel_iv);
//        cancelImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                closeAnimation();
//            }
//        });
//        for (int i = 0; i < 4; i++) {
//            View itemView = View.inflate(WeiboActivity.this, R.layout.item_icon, null);
//            ImageView menuImage = itemView.findViewById(R.id.menu_icon_iv);
//            TextView menuText = itemView.findViewById(R.id.menu_text_tv);
//
//            menuImage.setImageResource(menuIconItems[i]);
//            menuText.setText(menuTextItems[i]);
//
//            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
//            params.weight = 1;
//            itemView.setLayoutParams(params);
//            itemView.setVisibility(View.GONE);
//            menuLayout.addView(itemView);
//        }
//        return view;
//    }

    //
//    private void showMunu() {
//        startAnimation();
//        mHandler.post(new Runnable() {
//            @Override
//            public void run() {
//                //＋ 旋转动画
//                cancelImageView.animate().rotation(90).setDuration(400);
//            }
//        });
//        //菜单项弹出动画
//        for (int i = 0; i < menuLayout.getChildCount(); i++) {
//            final View child = menuLayout.getChildAt(i);
//            child.setVisibility(View.INVISIBLE);
//            mHandler.postDelayed(new Runnable() {
//
//                @RequiresApi(api = Build.VERSION_CODES.HONEYCOMB)
//                @Override
//                public void run() {
//                    child.setVisibility(View.VISIBLE);
//                    ValueAnimator fadeAnim = ObjectAnimator.ofFloat(child, "translationY", 600, 0);
//                    fadeAnim.setDuration(500);
//                    KickBackAnimator kickAnimator = new KickBackAnimator();
//                    kickAnimator.setDuration(500);
//                    fadeAnim.setEvaluator(kickAnimator);
//                    fadeAnim.start();
//                }
//            }, i * 50 + 100);
//        }
//    }


//    private void startAnimation() {
//        mHandler.post(new Runnable() {
//            @Override
//            public void run() {
//                try {
//                    //圆形扩展的动画
//                    if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
//                        int x = NavigationUtil.getScreenWidth() / 2;
//                        int y = (int) (NavigationUtil.getScreenHeith(WeiboActivity.this) - NavigationUtil.dip2px(WeiboActivity.this, 25));
//                        Animator animator = ViewAnimationUtils.createCircularReveal(navigationBar.getAddViewLayout(), x,
//                                y, 0, navigationBar.getAddViewLayout().getHeight());
//                        animator.addListener(new AnimatorListenerAdapter() {
//                            @Override
//                            public void onAnimationStart(Animator animation) {
//                                navigationBar.getAddViewLayout().setVisibility(View.VISIBLE);
//                            }
//
//                            @Override
//                            public void onAnimationEnd(Animator animation) {
//                                //							layout.setVisibility(View.VISIBLE);
//                            }
//                        });
//                        animator.setDuration(300);
//                        animator.start();
//                    }
//                } catch (Exception e) {
//                    e.printStackTrace();
//                }
//            }
//        });
//
//    }

    /**
     * 关闭window动画
     */
//    private void closeAnimation() {
//        mHandler.post(new Runnable() {
//            @Override
//            public void run() {
//                cancelImageView.animate().rotation(0).setDuration(400);
//            }
//        });
//
//        try {
//            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.LOLLIPOP) {
//
//                int x = NavigationUtil.getScreenWidth(this) / 2;
//                int y = (NavigationUtil.getScreenHeith(this) - NavigationUtil.dip2px(this, 25));
//                Animator animator = ViewAnimationUtils.createCircularReveal(navigationBar.getAddViewLayout(), x,
//                        y, navigationBar.getAddViewLayout().getHeight(), 0);
//                animator.addListener(new AnimatorListenerAdapter() {
//                    @Override
//                    public void onAnimationStart(Animator animation) {
//                        //							layout.setVisibility(View.GONE);
//                    }
//
//                    @Override
//                    public void onAnimationEnd(Animator animation) {
//                        navigationBar.getAddViewLayout().setVisibility(View.GONE);
//                        //dismiss();
//                    }
//                });
//                animator.setDuration(300);
//                animator.start();
//            }
//        } catch (Exception e) {
//        }
//    }
    public EasyNavigationBar getNavigationBar() {
        return navigationBar;
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initView(savedInstanceState);
    }

    /*@Override
    public int getContentLayout() {
        return R.layout.activity_main;
    }*/

    public void initView(Bundle savedInstanceState) {
        navigationBar = findViewById(R.id.navigationBar);

        fragments.add(new HomeFragment());
        fragments.add(new SeeFragment());
        fragments.add(new CustomerFragment());
        fragments.add(new MeFragment());

        navigationBar.titleItems(tabText)
                .normalIconItems(normalIcon)
                .selectIconItems(selectIcon)
                .fragmentList(fragments)
                .fragmentManager(getSupportFragmentManager())
                .addLayoutRule(EasyNavigationBar.RULE_BOTTOM)
                .addLayoutBottom(100)
                .onTabClickListener(new EasyNavigationBar.OnTabClickListener() {
                    @Override
                    public boolean onTabClickEvent(View view, int position) {
                        if (position == 4) {
                            /*Toast.makeText(WeiboActivity.this, "请先登录", Toast.LENGTH_SHORT).show();*/
                            //return true则拦截事件、不进行页面切换
                            return true;
                        } else if (position == 2) {
                            //跳转页面（全民K歌）   或者   弹出菜单（微博）
//                            showMunu();
                        }
                        return false;
                    }
                })
                .mode(EasyNavigationBar.MODE_ADD)
                .anim(Anim.ZoomIn)
                .build();


//        navigationBar.setAddViewLayout(createWeiboView());
    }
}
