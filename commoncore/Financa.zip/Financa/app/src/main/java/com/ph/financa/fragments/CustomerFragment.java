package com.ph.financa.fragments;


import android.os.Bundle;

import com.ph.financa.R;

import tech.com.commoncore.base.BaseFragment;

/**
 * 客户
 */

public class CustomerFragment extends BaseFragment {

    @Override
    public int getContentLayout() {
        return R.layout.fragment_customer;
    }

    @Override
    public void initView(Bundle savedInstanceState) {

    }
}
