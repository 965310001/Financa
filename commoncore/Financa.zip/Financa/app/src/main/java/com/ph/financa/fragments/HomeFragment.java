package com.ph.financa.fragments;


import android.os.Bundle;

import com.ph.financa.R;

import tech.com.commoncore.base.BaseFragment;

/**
 * 首页
 */

public class HomeFragment extends BaseFragment {

    @Override
    public int getContentLayout() {
        return R.layout.fragment_home;
    }

    @Override
    public void initView(Bundle savedInstanceState) {

    }
}
