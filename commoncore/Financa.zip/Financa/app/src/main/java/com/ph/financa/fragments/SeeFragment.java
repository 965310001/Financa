package com.ph.financa.fragments;


import android.os.Bundle;

import com.ph.financa.R;

import tech.com.commoncore.base.BaseFragment;

/**
 * 谁看了我
 */

public class SeeFragment extends BaseFragment {

    @Override
    public int getContentLayout() {
        return R.layout.fragment_me;
    }

    @Override
    public void initView(Bundle savedInstanceState) {

    }
}
