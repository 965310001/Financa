package tech.com.commoncore.base;

/**
 * Created: AriesHoo on 2017/6/29 16:39
 * Function:
 * Desc:
 */
public class BaseEntity<T> {
    public int code;
    public String msg;
    public T data;
}
