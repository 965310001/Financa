package tech.com.commoncore.event;

import com.vise.xsnow.event.IEvent;

/**
 * Anthor:NiceWind
 * Time:2019/3/22
 * Desc:The ladder is real, only the climb is all.
 *
 * 圈子改变通知.
 */
public class CircleChangeEvent implements IEvent{



}
